import React, {Component} from 'react';
import ReactDOM from 'react-dom';
import Index from '../Components/index';

var Indexobj = React.createElement(Index, {});
ReactDOM.render(Indexobj, document.getElementById('ReactJasminKarma'));