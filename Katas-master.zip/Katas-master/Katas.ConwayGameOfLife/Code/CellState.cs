﻿namespace Katas.ConwayGameOfLife.Code
{
    public enum CellState
    {
        Alive,
        Dead
    }
}