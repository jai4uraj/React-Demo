# Prime Calculator Kata #

A method that, given an integer, returns true if it is a prime and false if it is not.

