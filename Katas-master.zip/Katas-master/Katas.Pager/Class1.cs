﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Katas.Pager
{
    /// <summary>
    /// http://kaczanowscy.pl/tomek/2013-04/code-kata-pager
    /// </summary>
    public class Class1
    {
    }
}
