Katas
=====

A collection of TDD exercises that are useful as katas
